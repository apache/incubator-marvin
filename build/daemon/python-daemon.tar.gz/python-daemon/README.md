# Marvin Daemon

A daemon using the gRPC protocol with contains all the functionality of the old toolbox. This daemon will be in the docker container to maintain communication between the CLI and the container.